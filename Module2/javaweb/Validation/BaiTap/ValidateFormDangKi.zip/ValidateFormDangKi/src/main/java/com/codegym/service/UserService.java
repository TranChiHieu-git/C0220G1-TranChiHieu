package com.codegym.service;

import com.codegym.model.User;

public interface UserService {
    void saveUser(User user);
}
